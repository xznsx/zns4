<?php 
    header("Location: ../");
    exit;